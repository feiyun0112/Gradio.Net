import { z, _ } from "../chunks/2.BqWhUxOo.js";
export {
  z as component,
  _ as universal
};
